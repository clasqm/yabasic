objdump -p ./usr/local/bin/yabasic | grep NEEDED > dependencies.txt

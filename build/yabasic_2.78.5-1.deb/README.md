# yabasic_2.78.5

This depository contains the framework for creating a bare-bones .DEB file for the yabasic programming language.

The DEB you can download here requires an x86_64 linux to run on. but you can always clone the git repository and run the shell script to make your own 32-bit version.

There was a DEB version on the www.yabasic.de website last time I looked, but the dependencies were a little old-fashioned and it segfaulted immediately. So I decided to make my own. By all means try both.

